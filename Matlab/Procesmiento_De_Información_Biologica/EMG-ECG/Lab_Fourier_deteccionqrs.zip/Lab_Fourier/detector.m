% Esta función está diseñada para detectar las frecuencias  principales que
% componen el espectro de una seña, a través de la ttransformada de Fourier

function [fdet, potencia,y]= detector(s)

Fs = 1000;              % Frecuencia de toma de muestras de la señal s 
                        % (este valor puede variar)
T = 1/Fs;               % Tiempo entre la toma de una muestra y la siguiente
L = 1000;               % Cantidad de muestras que queremos tomar
t = (0:L-1)*T;          % Creamos un vector de tiempo
NFFT=2^nextpow2(L);     % Encontramos el vaalor digital (2^10) mas cercano a L
y=fft(s/1000,NFFT/2+1);      % Encontramos la transformada de Fourier de s(0:NFFT/2+1)
f = Fs*linspace(0,1,NFFT/2+1);  % Creamos un vector de frecuencias es decir el 
                                % eje de las frecuencias en un grafico de
                                % Magnitud de Fourier            
figure,plot(f,abs(y(1:NFFT/2+1))) %  Graficamos la transformada de Fourier
xlabel('Frecuenncia en Hz')
ylabel('|F(s)|')
%luego organizamos de mayor a menor los contenidos de potencia, esto
%permite que tomemos promero las frecuencias con mayor potencia que en
%teoría son las frecuencias de las señales principales
[potencia, fdet]=sort(abs(y(1:floor(size(f,2)/2))),'descend');
for j = 1:size(f,2)/2-1
    fdet(j,:) = f(fdet(j,:)); 
end

i=1;
disp('Las frecuencias principales de la señal son:\n')
while potencia(i)>(0.35*max(potencia))
    
    fprintf('%i\n',fdet(i))
    i=i+1;
end