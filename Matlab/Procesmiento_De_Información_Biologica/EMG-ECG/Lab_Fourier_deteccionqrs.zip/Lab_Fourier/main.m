
%Este taller esta pensado para poner en practica todo lo aprendido en la
%clase teorica a cerca de la transformada de Fourier. Por favor preste
%atención a los comentarios, pues estos le dirán que hacer para terminar
%este laboratorio


%% Punto 1. 
% En esta sección se lee una señal de una archivo, esta señal tiene un
% contenido espectral formado por varias señales, por lo que usted tendrá
% que identificar, cuantas señales hay inmersas en esta función y cuales
% son las frecuencias correspondientes a cada señal.

% Pimero ponga a correr este script tal cual como se encuentra y encontrará
% de forma más lógica lo que se le pide en este punto.
clear all
close all
clc
signal=load('signal.txt','w');
t=(0:size(signal,1)-1);
plot(t,signal)
xlabel('Tiempo');
ylabel('Amplitud')

%La funcion detector permite determinar las frecuencias que tienen
%componente de potencia más alto y la cantidad de energía contenida en
%dicha banda
%% Punto 1.a
% Lo primero que deberá hacer es comentar la linea 32 (siguiente línea de 
% código) y elaborar usted mismo una rutina que determine las frecuencias
% armonicas de las  señales que componen la función almacenada en el
% archivo .txt
% La variable frec
[ frec, pow, Tfourier]=detector(signal);

%% Punto 2
% En este bunto se busca usar la propiedad de multiplicacion de Fourier en la
% frecuencia, para eliminar las frecuencias que se encuentran mas allá de
% la primera componente de frecuencia por encima de cero y obtener la señal 
% resultante en el dominio del tiempo.

% Para hacer esto, el primer paso es descomentar la siguiente línea de
% código y ejecutar el script completo. ¡Recuerde que si no termina el
% primer punto, el segundo no funcionará!

%% codigo - Descomentar linea de abajo
filtrado=mi_fil(Tfourier, pow(1,1));

% En este punto usted ya habrá notado la señal que se esconce en el txt.Por
% esto usted tiene que volver a comentar la linea 47 y desarrollar su
% propio procedimiento para encontrar la señal que se esconde.
