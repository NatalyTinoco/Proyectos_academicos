function nfrecs=mi_fil(vfft, pot)
multiplo=zeros(size(vfft,1),1);
for j=1:size(vfft,1)
    if abs(vfft(j,1))==pot
        multiplo(j,1)=1;
        multiplo(j+1,1)=1;
        multiplo(j+2,1)=1;
        multiplo(j+4,1)=1;
        multiplo(j+5,1)=1;
        multiplo(j+6,1)=1;
        multiplo(j+7,1)=1;
        multiplo(j+8,1)=1;
        multiplo(j+9,1)=1;
        multiplo(j+10,1)=1;
        multiplo(j+12,1)=1;
        multiplo(j+14,1)=1;
    end
end
nfrecs=multiplo.*vfft;
ns=ifft(nfrecs);
ns=[ns; ns];
plot(0:2*513-1,abs(ns))
