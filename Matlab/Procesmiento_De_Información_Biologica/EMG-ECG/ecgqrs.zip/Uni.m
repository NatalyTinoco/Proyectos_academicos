function Esc = Uni(n,tam)
    Esc=zeros(1,tam);
    for i=1:n
        Esc(i)=1;    
    end
end
