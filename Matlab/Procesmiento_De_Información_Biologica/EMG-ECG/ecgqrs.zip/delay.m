function delay(seconds)
    % function pause the program
    % seconds = delay time in seconds
tic;
    while toc < seconds
    end
end